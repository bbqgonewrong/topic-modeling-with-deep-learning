from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
from tensorflow.python.keras.models import Sequential,Model
from tensorflow.python.keras.layers import Dense,AveragePooling2D,Dropout,Flatten,Dense,Input,Concatenate
import os
import pandas as pd
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
import matplotlib.pylab as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import shutil
from sklearn.metrics import multilabel_confusion_matrix,classification_report
from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau
from tensorflow import keras
import tensorflow as tf
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.utils import class_weight
from sklearn.utils import shuffle
import json
import os, re


#Data directory stuff ###############################################
cache_dir = '/data/s4133366/data_cache'
train_dir = '/data/s4133366/data/train'
save_dir = '/data/s4133366/saved_models'
data_dir = '/data/s4133366/data'
model_name = 'topic_weight_k4_imp_3_1'
model_string = 'Topic Model Implementation for EgoRoutine Dataset'
model_dir = os.path.join(save_dir,model_name)
history_dir = os.path.join(model_dir,'history')
train_metrics_path = 'history_'+model_name+'.npy'
res_path = 'results_'+model_name+'.npy'
plot_dir = os.path.join(model_dir,'plots')
####################################################################

def plot_metrics(history_path,results_path):
  read_train = np.load(history_path,allow_pickle=True).item()
  read_test = np.load(results_path,allow_pickle=True).item()
  history_path = os.path.split(history_path)[-1]
  #get_fold = history_path[-5]
  history_path = history_path.replace('.npy','')
  if not os.path.isdir(plot_dir):
    print('Plot directory '+plot_dir+' does not exist at the moment. Creating ....')
    os.mkdir(plot_dir)
  print(plot_dir+' created ...')
  if not os.path.isdir(os.path.join(plot_dir,history_path)) :
    os.mkdir(os.path.join(plot_dir,history_path))
    folder_path = os.path.join(plot_dir,history_path)
    print(folder_path+' created...')
  else:
    folder_path = os.path.join(plot_dir,history_path)
    print(folder_path,' exists ...')  
    print('Adding the metric plots to ',folder_path)

  #summarize history for accuracy

  plt.plot(read_train['categorical_accuracy'])
  plt.axhline(read_test['categorical_accuracy'], color='g', linestyle='--')
  plt.title('Model Categorical Accuracy for '+str(model_string))
  plt.ylabel('Categorical Accuracy')
  plt.xlabel('Epoch')
  plt.legend(['train', 'test'], loc='upper left')
  plt.savefig(os.path.join(folder_path,'accuracy_'+str(history_path)+'.png'))
  plt.clf()
  print('Categorical Accuracy plotted...')    
  # summarize history for loss

  plt.plot(read_train['loss'])
  plt.axhline(read_test['loss'], color='g', linestyle='--')
  plt.title('Model Loss for '+str(model_string))
  plt.ylabel('Loss')
  plt.xlabel('Epoch')
  plt.legend(['train', 'test'], loc='upper left')
  #plt.show()
  plt.savefig(os.path.join(folder_path,'loss_'+str(history_path)+'.png'))
  plt.clf()
  print('Loss plotted...')
  #summarize history for Precision 
  plt.plot(read_train['precision'])
  plt.axhline(read_test['precision'], color='g', linestyle='--')
  plt.title('Model Precision for '+str(model_string))
  plt.ylabel('Precision')
  plt.xlabel('Epoch')
  plt.legend(['train', 'test'], loc='upper left')
  plt.savefig(os.path.join(folder_path,'precision_'+str(history_path)+'.png'))
  plt.clf()
  print('Precision plotted...')    
  #summarize history for Recall 

  plt.plot(read_train['recall'])
  plt.axhline(read_test['recall'], color='g', linestyle='--')
  plt.title('Model Recall for '+str(model_string))
  plt.ylabel('Recall')
  plt.xlabel('Epoch')
  plt.legend(['train', 'test'], loc='upper left')
  plt.savefig(os.path.join(folder_path,'recall_'+str(history_path)+'.png'))
  plt.clf()
  print('Recall plotted...')        
  plt.plot(read_train['lr'])
  plt.title('Model Learning rate for '+str(model_string))
  plt.ylabel('Learning Rate')
  plt.xlabel('Epoch')
  plt.legend(['train', 'test'], loc='upper left')
  plt.savefig(os.path.join(folder_path,'lr_'+str(history_path)+'.png'))
  plt.clf()
  print('Learning rate plotted...')          
  print('Plotting successful....')

######### Change these values 

history_filename = os.path.join(history_dir,train_metrics_path)

history = np.load(history_filename,allow_pickle = True).item()
print(history)

results_filename = os.path.join(history_dir,res_path)
print('Storing results in :'+results_filename)
report =  np.load(results_filename,allow_pickle = True)
#np.save(results_filename, report)
########
print('Trying to plot ...')

print('Storing the plots in '+plot_dir+'....')    
plot_metrics(history_filename,results_filename)
 




print('Job ended ...')