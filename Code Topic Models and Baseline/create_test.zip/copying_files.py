import shutil
import pandas as pd
import numpy as np
import os
print('Reading source test csv ...')
data = pd.read_csv('/data/s4133366/data/new_test.csv')
print('Copying data ...')
source = data['Path']
dest = data['Image']
for i,j in zip(source,dest):
    print('Copying ',i)
    if os.path.isfile(i):
        if not os.path.isfile(j):
            print(j,' does not exist yet')
            shutil.copy(i,j)
            print(j,' copied')
        else: 
            print('file exists')
    else:
        print(i,' does not exist...')
print('done')