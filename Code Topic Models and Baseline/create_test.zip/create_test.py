import glob
import pandas as pd
import numpy as np
files = []
#print(files)
print(glob.glob("/data/s4133366/places365_20/val/*/*.jpg"))
mylist = [f for f in glob.glob('/data/s4133366/places365_20/val/*/*.jpg')]
#files.append(data)
final = pd.DataFrame(mylist)
final.columns = ['Image']
final['Label'] = final['Image'].apply(lambda x:x.split('/')[-2])
print(final.head())
final.to_csv('/data/s4133366/places365_20/val_p20.csv')