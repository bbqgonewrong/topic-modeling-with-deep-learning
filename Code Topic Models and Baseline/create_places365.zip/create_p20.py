import pandas as pd
import numpy as np
train = pd.read_csv('/data/s4133366/places365_20/train_p20.csv')
labels = np.unique(train['Label'])
df_list_train = []
df_list_test = []
for label in labels:
    print('Label : ',label)
    df_place = train[train['Label']==label]
    df_place_train = df_place.sample(1400,random_state = 42)
    print('Place '+label+' count train: '+str(len(df_place_train)))
    df_list_train.append(df_place_train)
    df_place_test = df_place[~df_place.index.isin(df_place_train.index)]
    print('Place '+label+' count test: ',str(len(df_place_test)))
    df_list_test.append(df_place_test)

train_final = pd.concat(df_list_train)
test_final = pd.concat(df_list_test)
print(len(train_final))
print(len(test_final))  
print(train_final.head())
print(test_final.head())
mergedStuff = pd.merge(train_final, test_final, on=['Image'], how='inner')
print(len(mergedStuff))
train_final.to_csv('/data/s4133366/places365_20/train_p20_final.csv')
test_final.to_csv('/data/s4133366/places365_20/test_p20_final.csv')