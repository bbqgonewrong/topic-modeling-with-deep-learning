import tarfile
#!wget 'http://data.csail.mit.edu/places/places365/places365standard_easyformat.tar'


my_tar = tarfile.open('/data/s4133366/places365standard_easyformat.tar')
my_tar.extractall('/data/s4133366') # specify which folder to extract to
my_tar.close()
print('Ended ...')