from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
from tensorflow.python.keras.models import Sequential,Model
from tensorflow.python.keras.layers import Dense,AveragePooling2D,Dropout,Flatten,Dense,Input,Concatenate,GlobalAveragePooling2D
import os
import pandas as pd
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
import matplotlib.pylab as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import shutil
from sklearn.metrics import confusion_matrix,classification_report
from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau,TensorBoard,LambdaCallback
from tensorflow import keras
import tensorflow as tf
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.utils import class_weight
from PIL import Image
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.preprocessing.image import array_to_img
from glob import glob
import shutil
import json
from json import JSONEncoder
import seaborn as sn
from sklearn.utils.class_weight import compute_sample_weight
#import tensorflow_addons as tfa
#from tensorflow_addons.losses import SigmoidFocalCrossEntropy
from keras import backend as K

best_topic_resnet_list = []
fileList = []
numpy_dir = '/data/s4133366/data/topic_places_train'
save_dir = '/data/s4133366/saved_models'
model_name = 'topic_weight_k4_imp_9_2'
model_dir = os.path.join(save_dir,model_name)
topic_dir = os.path.join(model_dir,'topic')
if not os.path.isdir(topic_dir):
    print('Topic directory for model '+model_name+' not created yet...Creating')
    os.mkdir(topic_dir)
    print('Created: '+topic_dir)
else:
    print('Topic directory already present at : '+topic_dir)

def plot_objects_place(dataFile,place,topic_dir):    
    test = pd.read_csv(dataFile)
    test = test[['Image','Object']]
    
    image_name = place+'.png'
    image_path = os.path.join(topic_dir,image_name)
    test.Object.value_counts().sort_values().plot(kind = 'barh')
    plt.xlabel('Number of Images')
    plt.ylabel('Objects')
    plt.title('Top 10 Objects highlighted by Resnet-50 for Place: '+place)
    #plt.xticks([])
    plt.savefig(os.path.join(topic_dir,image_path))
    plt.clf()

def plot_objects_place_topic(dataFile,place,topic,topic_dir):    
    test = pd.read_csv(dataFile)
    test = test[['Image','Object']]
    
    image_name = place+'_'+topic+'.png'
    image_path = os.path.join(topic_dir,image_name)
    test.Object.value_counts().sort_values().plot(kind = 'barh')
    plt.xlabel('Number of Images')
    plt.ylabel('Objects')
    plt.title('Top 10 Objects highlighted by'+topic+' Layer for Place: '+place)
    #plt.xticks([])
    plt.savefig(os.path.join(topic_dir,image_path))
    plt.clf()



def create_object_count_data(csv_file,place_name,topic_dir):
    data_segs = pd.read_csv(csv_file)
    df_list = []
    print(data_segs.head())
    for i in range(len(data_segs)):
        #elements = 'df_'+str(i)
        print('Creating df: ')
        place_element =data_segs.iloc[i,1:11]
        print('Values:',place_element)
        #df_sample = pd.DataFrame(place_element,columns = ['Object'])
        df_sample = pd.DataFrame(place_element)
        df_sample.columns = ['Object']
        df_sample['Image'] = 'Image '+str(i)
        
        df_store = df_sample
        df_sample = df_sample[0:0] 
        #print(df_store.head())
        df_list.append(df_store)
        #print('Created :Dataframe ',df_sample)
        
    final_df = pd.concat(df_list,sort=True)
    #print(final_df)
    csv_filename = place_name+'.csv'
    topic_subdir = os.path.join(topic_dir,'resnet')
    if not os.path.isdir(topic_subdir):
        print('Directory not present yet... creating')
        print(os.mkdir(topic_subdir))
    else:
        print(topic_subdir+' already present...')
    csv_path = os.path.join(topic_subdir,csv_filename)
    final_df.to_csv(csv_path)
    plot_objects_place(csv_path,place_name,topic_subdir)
    print(final_df.head())
    
    return final_df

def create_object_count_data_topic(csv_file,place_name,topic,topic_dir):
    data_segs = pd.read_csv(csv_file)
    df_list = []
    print(data_segs.head())
    for i in range(len(data_segs)):
        #elements = 'df_'+str(i)
        print('Creating df: ')
        place_element =data_segs.iloc[i,1:11]
        print('Values:',place_element)
        #df_sample = pd.DataFrame(place_element,columns = ['Object'])
        df_sample = pd.DataFrame(place_element)
        df_sample.columns = ['Object']
        df_sample['Image'] = 'Image '+str(i)
        
        df_store = df_sample
        df_sample = df_sample[0:0] 
        #print(df_store.head())
        df_list.append(df_store)
        #print('Created :Dataframe ',df_sample)
        
    final_df = pd.concat(df_list,sort=True)
    #print(final_df)
    csv_filename = place_name+'_'+topic+'.csv'
    topic_subdir = os.path.join(topic_dir,topic)
    if not os.path.isdir(topic_subdir):
        print('Directory not present yet... creating')
        print(os.mkdir(topic_subdir))
    else:
        print(topic_subdir+' already present...')
    csv_path_topic = os.path.join(topic_subdir,csv_filename)
    final_df.to_csv(csv_path_topic)
    plot_objects_place_topic(csv_path_topic,place_name,topic,topic_subdir)
    print(final_df.head())
    
    return final_df


#fileList = []

for file in os.listdir(numpy_dir):
    if(file.endswith('.npy')):
        fileList.append(file)
        
print(fileList)
print(len(fileList))
fileList = ['/data/s4133366/data/topic_places_train/Water_train_arrays.npy']
#

print('Loading model ...')

cent_model = keras.models.load_model(os.path.join(model_dir,model_name+'_eval'))
print('Model:'+os.path.join(model_dir,model_name+'_eval')+' loaded ...')

for file in fileList:
    best_topic_resnet_list = []
    best_topic_t1_list = []
    best_topic_t2_list = []
    best_topic_t3_list = []
    best_topic_t4_list = []
    print('Found file: ',file)
    data = np.load(os.path.join(numpy_dir,file),allow_pickle = True)
    placeName = file.split('/')[-1]
    placeName = placeName.replace('_train_arrays.npy','')
    print('Place',placeName)
    #if placeName not in ['Transportation','Pathways','Office']:
    get_base_output = K.function([cent_model.input],[cent_model.get_layer('predictions').output])
    get_t1_output = K.function([cent_model.input],[cent_model.get_layer('topic_1').output])
    get_t2_output = K.function([cent_model.input],[cent_model.get_layer('topic_2').output])
    get_t3_output = K.function([cent_model.input],[cent_model.get_layer('topic_3').output])
    get_t4_output = K.function([cent_model.input],[cent_model.get_layer('topic_4').output])
    
    #RESNET PREDICTIONS
    #image_test = tf.expand_dims(image, 0)
    resnet = get_base_output(data)[0]
    resnet_all = get_base_output(data)
    print(resnet.shape)
    #print(resnet_all)
    
    resnet_test = np.squeeze(resnet)
    
    best_topics_resnet = np.argsort(resnet_test,axis=1)[:,-10:]
    #best_topics_resnet = np.argsort(resnet_test)[-n:]
    print('Shape of resnet test:',resnet_test.shape)
    print('Shape of best_topics:',best_topics_resnet.shape)
    best_topic_resnet_list.append(best_topics_resnet)
    #for val in best_topic_resnet_list:
    #    print('Resnet-50 prediction value:',resnet_test[val])
    
    #df_File = pd.DataFrame(best_topics_resnet_list)
    #df_File.head()
    #df_File.to_csv('testing.csv')    
    
    
    
    print('Final Topics:',best_topic_resnet_list)
    df_File = pd.DataFrame(np.squeeze(best_topic_resnet_list))
    print(df_File.shape[0])
    df_File['Objects'] = list(np.squeeze(best_topic_resnet_list))
    df_File['Image'] = range(len(df_File))
    df_File['Image'] = df_File['Image'].apply(lambda x:'Image '+str(x))
    csv_file = 'predictions_'+placeName+'.csv'
    csv_path = os.path.join(topic_dir,csv_file)
    df_File.to_csv(csv_path)
    final_df = create_object_count_data(csv_path,placeName,topic_dir)
    print('Clearing the previous data frame')
    df_File = df_File[0:0]
    
    #TOPIC 1
    
    topic_1 = get_t1_output(data)[0]
    print(topic_1.shape)
    
    topic_1_test = np.squeeze(topic_1)
    
    best_topics_t1 = np.argsort(topic_1_test,axis=1)[:,-10:]
    #best_topics_resnet = np.argsort(resnet_test)[-n:]
    print('Shape of resnet test:',topic_1_test.shape)
    print('Shape of best_topics:',best_topics_t1.shape)
    best_topic_t1_list.append(best_topics_t1)
    
    
    
    print('Final Topics:',best_topic_t1_list)
    df_Topic1 = pd.DataFrame(np.squeeze(best_topic_t1_list))
    print(df_Topic1.shape[0])
    df_Topic1['Objects'] = list(np.squeeze(best_topic_t1_list))
    df_Topic1['Image'] = range(len(df_Topic1))
    df_Topic1['Image'] = df_Topic1['Image'].apply(lambda x:'Image '+str(x))

    csv_topic1 = 'topic1_'+placeName+'.csv'
    topic1_csv_path = os.path.join(topic_dir,csv_topic1)
    df_Topic1.to_csv(topic1_csv_path)
    final_topic1 = create_object_count_data_topic(topic1_csv_path,placeName,'Topic 1',topic_dir)
    print('Clearing the previous data frame')
    df_Topic1 = df_Topic1[0:0]
    
    
    #TOPIC 2
    topic_2 = get_t2_output(data)[0]
    print(topic_2.shape)
    
    topic_2_test = np.squeeze(topic_2)
    
    best_topics_t2 = np.argsort(topic_2_test,axis=1)[:,-10:]
    #best_topics_resnet = np.argsort(resnet_test)[-n:]
    print('Shape of resnet test:',topic_2_test.shape)
    print('Shape of best_topics:',best_topics_t2.shape)
    best_topic_t2_list.append(best_topics_t2)
    
    
    
    print('Final Topics:',best_topic_t2_list)
    df_Topic2 = pd.DataFrame(np.squeeze(best_topic_t2_list))
    print(df_Topic2.shape[0])
    df_Topic2['Objects'] = list(np.squeeze(best_topic_t2_list))
    df_Topic2['Image'] = range(len(df_Topic2))
    df_Topic2['Image'] = df_Topic2['Image'].apply(lambda x:'Image '+str(x))
    
    csv_topic2 = 'topic2_'+placeName+'.csv'
    topic2_csv_path = os.path.join(topic_dir,csv_topic2)
    df_Topic2.to_csv(topic2_csv_path)
    final_topic2 = create_object_count_data_topic(topic2_csv_path,placeName,'Topic 2',topic_dir)
    print('Clearing the previous data frame')
    df_Topic2 = df_Topic2[0:0]
    
    
    
    #TOPIC 3
    topic_3 = get_t3_output(data)[0]
    print(topic_3.shape)
    
    topic_3_test = np.squeeze(topic_3)
    
    best_topics_t3 = np.argsort(topic_3_test,axis=1)[:,-10:]
    #best_topics_resnet = np.argsort(resnet_test)[-n:]
    print('Shape of resnet test:',topic_3_test.shape)
    print('Shape of best_topics:',best_topics_t3.shape)
    best_topic_t3_list.append(best_topics_t3)
    
    
    
    print('Final Topics:',best_topic_t3_list)
    df_Topic3 = pd.DataFrame(np.squeeze(best_topic_t3_list))
    print(df_Topic3.shape[0])
    df_Topic3['Objects'] = list(np.squeeze(best_topic_t3_list))
    df_Topic3['Image'] = range(len(df_Topic3))
    df_Topic3['Image'] = df_Topic3['Image'].apply(lambda x:'Image '+str(x))

    csv_topic3 = 'topic3_'+placeName+'.csv'
    topic3_csv_path = os.path.join(topic_dir,csv_topic3)
    df_Topic3.to_csv(topic3_csv_path)
    final_topic3 = create_object_count_data_topic(topic3_csv_path,placeName,'Topic 3',topic_dir)
    print('Clearing the previous data frame')
    df_Topic3 = df_Topic3[0:0]
    
    
    #TOPIC 4
    topic_4 = get_t4_output(data)[0]
    print(topic_4.shape)
    
    topic_4_test = np.squeeze(topic_4)
    
    best_topics_t4 = np.argsort(topic_4_test,axis=1)[:,-10:]
    #best_topics_resnet = np.argsort(resnet_test)[-n:]
    print('Shape of resnet test:',topic_4_test.shape)
    print('Shape of best_topics:',best_topics_t4.shape)
    best_topic_t4_list.append(best_topics_t4)
    
    
    
    print('Final Topics:',best_topic_t4_list)
    df_Topic4 = pd.DataFrame(np.squeeze(best_topic_t4_list))
    print(df_Topic4.shape[0])
    df_Topic4['Objects'] = list(np.squeeze(best_topic_t4_list))
    df_Topic4['Image'] = range(len(df_Topic4))
    df_Topic4['Image'] = df_Topic4['Image'].apply(lambda x:'Image '+str(x))
    csv_topic4 = 'topic4_'+placeName+'.csv'
    topic4_csv_path = os.path.join(topic_dir,csv_topic4)
    df_Topic4.to_csv(topic4_csv_path)
    final_topic4 = create_object_count_data_topic(topic4_csv_path,placeName,'Topic 4',topic_dir)
    print('Clearing the previous data frame')
    df_Topic4 = df_Topic4[0:0]
    
    print('Going to next image')
    

print('Done...')





#
