from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
from tensorflow.python.keras.models import Sequential,Model
from tensorflow.python.keras.layers import Dense,AveragePooling2D,Dropout,Flatten,Dense,Input,Concatenate,GlobalAveragePooling2D
import os
import pandas as pd
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
import matplotlib.pylab as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import shutil
from sklearn.metrics import confusion_matrix,classification_report
from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau,TensorBoard,LambdaCallback
from tensorflow import keras
import tensorflow as tf
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.utils import class_weight
from PIL import Image
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.preprocessing.image import array_to_img
from glob import glob
import shutil
import json
from json import JSONEncoder
import seaborn as sn
from sklearn.utils.class_weight import compute_sample_weight
#import tensorflow_addons as tfa
#from tensorflow_addons.losses import SigmoidFocalCrossEntropy
from keras import backend as K
best_topic_resnet_list = []
#fileList = []

#for file in os.listdir('/home/s4133366/Desktop/topic_places_file'):
#    if(file.endswith('.npy')):
#        fileList.append(file)
        
#print(fileList)
fileList = ['/data/s4133366/data/topic_places_train/Water_train_arrays.npy']
print('Loading model ...')

cent_model = keras.models.load_model('/data/s4133366/saved_models/topic_weight_k4_imp_4_7/topic_weight_k4_imp_4_7_eval')
print('Model loaded ...')

for file in fileList:
    print('Found file: ',file)
    data = np.load(file,allow_pickle = True)
    
    get_base_output = K.function([cent_model.input],[cent_model.get_layer('predictions').output])
    get_t1_output = K.function([cent_model.input],[cent_model.get_layer('topic_1').output])
    get_t2_output = K.function([cent_model.input],[cent_model.get_layer('topic_2').output])
    get_t3_output = K.function([cent_model.input],[cent_model.get_layer('topic_3').output])
    get_t4_output = K.function([cent_model.input],[cent_model.get_layer('topic_4').output])
    for image in data:
        i=1
        print('Image',i)
        image_test = tf.expand_dims(image, 0)
        resnet = get_base_output(image_test)[0]
        resnet_all = get_base_output(image_test)
        print(resnet.shape)
        #print(resnet_all)
        
        resnet_test = np.squeeze(resnet)
        #best_topics_resnet = np.argsort(resnet_test)[-10:]
        #best_topics_resnet = np.argpartition(resnet_test,-10)[-10:]
        #best_topics_resnet = (-resnet_test).argsort()[:10]
        best_topics_resnet = np.argsort(resnet_test)[-20:]
        #best_topics_resnet = np.argsort(resnet_test)[-n:]
        print('Shape of best_topics:',best_topics_resnet.shape)
        best_topic_resnet_list.append(best_topics_resnet)
    for val in best_topic_resnet_list:
        print('Resnet-50 prediction value:',resnet_test[val])
        i = i+1
    #df_File = pd.DataFrame(best_topics_resnet_list)
    #df_File.head()
    #df_File.to_csv('testing.csv')    
    
    
    
print('Final Topics:',best_topic_resnet_list)
