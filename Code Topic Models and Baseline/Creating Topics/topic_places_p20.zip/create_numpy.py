from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
from tensorflow.python.keras.models import Sequential,Model
from tensorflow.python.keras.layers import Dense,AveragePooling2D,Dropout,Flatten,Dense,Input,Concatenate,GlobalAveragePooling2D
import os
import pandas as pd
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
import matplotlib.pylab as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import shutil
from sklearn.metrics import confusion_matrix,classification_report
from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau,TensorBoard,LambdaCallback
from tensorflow import keras
import tensorflow as tf
from sklearn.model_selection import KFold,StratifiedKFold
from sklearn.utils import class_weight
from PIL import Image
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.preprocessing.image import array_to_img
from glob import glob
import shutil
import json
from json import JSONEncoder
import seaborn as sn
from sklearn.utils.class_weight import compute_sample_weight
#import tensorflow_addons as tfa
#from tensorflow_addons.losses import SigmoidFocalCrossEntropy

#####

#numpy_list = ['Balcony_train_arrays.npy',
#'Bathroom_train_arrays.npy',
#'Beach_train_arrays.npy',
#'Bedroom_train_arrays.npy',
#'Buildings_train_arrays.npy',
#'Education,science_train_arrays.npy',
#'Forest, field, jungle_train_arrays.npy',
#'Garden_train_arrays.npy',
#'Hospital_train_arrays.npy',
#'Living room_train_arrays.npy',
#'Mountains, hills, desert, sky_train_arrays.npy',
#'Museum_train_arrays.npy',
#'Noise_train_arrays.npy',
#'Office_train_arrays.npy',
#'Other rooms_train_arrays.npy',
#'Others_train_arrays.npy',
#'Pathways_train_arrays.npy',
#'Recreation_train_arrays.npy',
#'Restaurant,Bar_train_arrays.npy',
#'Shop_train_arrays.npy',
#'Sport fields_train_arrays.npy',
#'Transportation_train_arrays.npy']
#print('Already created: ',len(numpy_list))
#####
remain = ['underwater-ocean_deep','sky']

def create_numpy_img_mul(imageList):
  img_list = []
  for image in imageList:
    print('Image: ',image)
    img = keras.preprocessing.image.load_img(
        image, target_size=(224,224,3)
    )
    img_array = keras.preprocessing.image.img_to_array(img)
    img_array = img_array/255.
    # img_array = tf.expand_dims(img_array, 0)
    img_list.append(img_array)
  x = tf.stack(img_list)

  return x

test_data = pd.read_csv('/data/s4133366/places365_20/train_p20_final.csv')
places_labels_list = list(np.unique(test_data['Label']))
print('Places list:',places_labels_list)
place_array_file = 'topic_places_train_p20'
place_array_files = os.path.join('/data/s4133366/places365_20',place_array_file)

#os.path.isfile('/home/s4133366/Desktop/topic_places_file/'+place+'_train_arrays.npy'):
for place in places_labels_list:
    if place in remain:
        df_places = test_data[test_data['Label']== place]
        
        print('Length of Data : ',len(df_places))
        images = list(df_places['Image'])
        images_count = len(list(df_places['Image']))
        print('Images: place '+place+' Images count'+str(images_count))
        
        
        print('Running the tensor dec function for: '+place)
        images_place = create_numpy_img_mul(images)
        print(df_places.head(5))
        
        print('Storing '+place+' image ...')
        place_filename = os.path.join(place_array_files,place+'_train_arrays.npy')
        #if(~os.path.isdir(place_filename)):
        #    os.mkdir(place_filename)
        np.save(os.path.join(place_array_files,place+'_train_arrays.npy'),images_place)
        print('Stored at ...',place_filename)
        print(place+' Shape:'+str(len(images_place)))
        print(type(images_place))
        
        print('Going to next Place ....')
    else:
        print('topic_places_train'+place+'_train_arrays.npy already exists')
    